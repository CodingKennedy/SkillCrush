<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'skill203');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '<0ZLV+Cn03;EZcZUw3:6l%;nz,o&)IAu]dH~e34;ILD>wN+ou$.q<Zp%Id~i/]?;');
define('SECURE_AUTH_KEY',  '}UN~%y&PF 6RUyTaa|eK&M+`?|5)%hWyd+WMtikrVl+wvJbJbm-}I1o EnN=U8/%');
define('LOGGED_IN_KEY',    '|v=~2mnL3^B%U%W [-Nf!K[IP*J]Ms+-eNIJ*5=|p 6X%9XcAp3-]:Aq^i$Ax?H,');
define('NONCE_KEY',        'IuDt~hh>Q~@-5wa $Tjw#s307qgz8G~mN?vgN.l#+<8B`0v-Y&C1=-e!=sR6rBuQ');
define('AUTH_SALT',        ':@ugrIh}1V{D5ZeVh:Xz`. &!f<Y(d}v_I?V(re?>AB)xn*yTw:|3aToN~5qU%N`');
define('SECURE_AUTH_SALT', ')4Qesk.AWoimEq%B9L;l7g]ltW5bK_~U|^*F,@acOO_yUh>=oGWhB$X7NvX~R3aD');
define('LOGGED_IN_SALT',   '9de:9,Ds?nYx+xiBi>-OhS!PH1^|g)e(s5v0fum?!|3& RY!,+BEbpO/XsYKX]YY');
define('NONCE_SALT',       'E[9DDdF%]~JokZGOO!xf{np&SodB+Bl>((`-8Am(YKV.PVFh/1;qP2)ZpUOovaZd');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
